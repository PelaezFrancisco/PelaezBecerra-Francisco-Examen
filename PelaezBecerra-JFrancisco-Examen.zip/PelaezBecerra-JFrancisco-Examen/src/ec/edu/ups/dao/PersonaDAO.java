package ec.edu.ups.dao;

import ec.edu.ups.entidades.Persona;

public interface PersonaDAO extends GenericDAO<Persona, Integer, String>{

}
