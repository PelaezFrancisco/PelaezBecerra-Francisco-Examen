package ec.edu.ups.dao;

import ec.edu.ups.entidades.Telefonos;

public interface TelefonosDAO extends GenericDAO<Telefonos, Integer, String>{

}
