package ec.edu.ups.dao;

import ec.edu.ups.entidades.Operadoras;

public interface OperadorasDAO extends GenericDAO<Operadoras, Integer, String>{

}
