package ec.edu.ups.dao;

import ec.edu.ups.entidades.Tipo;

public interface TipoDAO extends GenericDAO<Tipo, Integer, String>{

}
